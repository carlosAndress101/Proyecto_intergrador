package sample;

import com.jfoenix.controls.JFXButton;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class RegistroController {
    @FXML
    private JFXButton CancelarB;
    @FXML
    private TextField txtNombre;
    @FXML
    private TextField txtApellido;
    @FXML
    private TextField txtCodigo;


    //----------------metodos OnAction----------------------
    public void CancelarOnAction(ActionEvent event) {
        Stage stage = (Stage) CancelarB.getScene().getWindow();
        stage.close();
    }

    // ***********************conectar con base de datos y insertar persona a sqlite3*************************
    public class ConnectionCH {
        String conetionDB = "jdbc:sqlite:C:/Users/carlo/Documents/App_Tienda/src/sample/Base_de_datos/usuarios.db";
        Connection connection = null;

        public ConnectionCH() {
            try {
                Class.forName("org.sqlite.JDBC");
                connection = DriverManager.getConnection(conetionDB);
                if (connection != null) {
                    System.out.println("conectado☺");
                }
            } catch (SQLException | ClassNotFoundException e) {
                System.out.println("Error en la conexión de la base de datos" + e.getMessage());
            }
        }

        public void ejecutarSentenciaSQLite() throws SQLException {
            String nombre = txtNombre.getText();
            String apellido = txtApellido.getText();
            long codigo = Long.parseLong(txtCodigo.getText());
            PreparedStatement pstm = connection.prepareStatement("INSERT INTO Users(nombre, apellido, codigo) VALUES(?,?,?)");
            try {
                pstm.setString(1, nombre);
                pstm.setString(2, apellido);
                pstm.setString(3, String.valueOf(codigo));
                pstm.executeUpdate();

            } catch (SQLException e) {
                System.out.println("esta malo" + e.getMessage());
            } finally {
                try {
                    connection.close();
                    pstm.close();
                } catch (Exception e) {
                    System.out.println("no se ha cerrado" + e.getMessage());
                }
            }

        }
    }

    public void OnActionAgregar(ActionEvent event) throws SQLException {
        ConnectionCH conect = new ConnectionCH();
        conect.ejecutarSentenciaSQLite();
    }
}