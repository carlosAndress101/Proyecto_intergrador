SELECT Nombre, Apellido, Codigo FROM Users;

INSERT INTO Users(Nombre, Apellido, Codigo) VALUES('','','')